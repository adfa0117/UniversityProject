#include <vector>
#include <iostream>
#include "Unit.h"
#include "Attacker.h"
#include "Miner.h"
#include "ApplicationType.h"

using namespace std;

int main() {
	ApplicationType appType;
	appType.run();
	return 0;
}