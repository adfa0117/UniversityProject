from PyToMc.mcpi import minecraft
import math
import urllib.request
from PIL import Image
from io import BytesIO
import numpy as np

mc = minecraft.Minecraft.create()

posL = []
entityIdL = []
sizeL = []

while True:
    chatEvents = mc.events.pollChatPosts()
    chat = ""
    entityId = 0
    for chatEvent in chatEvents:
        chat = chatEvent.message
        entityId = chatEvent.entityId
        cmd = chat.split(" ")
        args = len(cmd)
        name = mc.entity.getName(entityId)
        if chat == "exit":
            mc.postToChat("종료합니다.")
            break
        elif chat == "reg":
            if entityId in entityIdL:
                mc.postToChat(name + "님은 이미 등록되어 있습니다.")
            else:
                entityIdL.append(entityId)
                posL.append([0, -1, 0])
                sizeL.append([-1, -1])
                mc.postToChat(name + "님이 등록되었습니다..")
        if entityId in entityIdL:
            index = entityIdL.index(entityId)
            if args == 1:
                if cmd[0] == "setPos":
                    pos = mc.entity.getPos(entityId)
                    x = math.floor(pos.x)
                    y = math.floor(pos.y)
                    z = math.floor(pos.z)
                    pos = [x, y, z]
                    posL[index] = pos
                    mc.postToChat("{0}님의 좌표가 {1}로 설정되었습니다.".format(name, pos))
                elif cmd[0] == "getPos":
                    if posL[index][1] == -1:
                        mc.postToChat(name + "님은 아직 좌표를 설정하지 않았습니다. setPos를 쳐서 좌표를 설정해 주세요.")
                    else:
                        mc.postToChat("{0}님의 좌표는 {1}입니다".format(name, posL[index]))
                elif cmd[0] == "setSize":
                    mc.postToChat("setSize width height")
                elif cmd[0] == "getSize":
                    if sizeL[index][0] == -1:
                        mc.postToChat(name + "님은 아직 크기를 설정하지 않았습니다. setSize를 쳐서 크기를 설정해 주세요.")
                    else:
                        mc.postToChat("{0}님의 크기는 {1}입니다.".format(name, sizeL[index]))
                elif cmd[0] == "print":
                    mc.postToChat("print url")
            elif args == 2:
                if cmd[0] == "print":
                    img = ""
                    try:
                        bImg = urllib.request.urlopen(cmd[1]).read()
                        img = Image.open(BytesIO(bImg))
                    except:
                        mc.postToChat("이미지를 받아오는데 실패하였습니다. 다시 시도해 보십시오.")
                    else:
                        if posL[index][1] == -1:
                            mc.postToChat(name + "님은 아직 좌표를 설정하지 않았습니다. setPos를 쳐서 좌표를 설정해 주세요.")
                        elif sizeL[index][0] == -1:
                            mc.postToChat(name + "님은 아직 크기를 설정하지 않았습니다. setSize를 쳐서 크기를 설정해 주세요.")
                        else:
                            pix = np.array(img)
                            x = posL[index][0]
                            y = posL[index][1]
                            z = posL[index][2]
                            for i in range(sizeL[index][0]):
                                for j in range(sizeL[index][1]):
                                    mc.setBlock(x + i, y, z + j, 251)
            elif args == 3:
                if cmd[0] == "setSize":
                    if cmd[1].isdigit() and cmd[2].isdigit():
                        sizeL[index] = [int(cmd[1]), int(cmd[2])]
                        mc.postToChat("{0}님의 크기가 {1}로 설정되었습니다.".format(name, sizeL[index]))
                    else:
                        mc.postToChat("크기는 숫자만 입력해주세요.")
        else:
            mc.postToChat(name + "님은 아직 등록하지 않으셨습니다 reg를 쳐서 등록해주세요.")
    if chat == "exit":
        break
