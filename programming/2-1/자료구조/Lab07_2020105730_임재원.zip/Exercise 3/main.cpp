#include <iostream>
#include "TextEditor.h"

int main()
{
	TextEditor editor;
	char item1[] = "Hello";
	char item2[] = "Hi";
	char item3[] = "Bye";
	char item[80];
	int pos;

	editor.InsertItem(item1);
	editor.InsertItem(item2);
	editor.InsertItem(item3);

	editor.GoToTop();
	editor.GetNextItem(item);
	
	pos = -1;
	while (item[++pos] != '\0')
	{
		std::cout << item[pos];
	}
	std::cout << std::endl;

	editor.GoToBottom();
	editor.GetNextItem(item);

	pos = -1;
	while (item[++pos] != '\0')
	{
		std::cout << item[pos];
	}
	std::cout << std::endl;
}