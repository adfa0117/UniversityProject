// ItemType.h StackDriver
#pragma once
const int MAX_ITEMS = 10;
typedef int ItemType;