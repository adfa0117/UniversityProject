#include "VecType.h"

int VecType::sum() const
{
	return a + b + c;
}

int VecType::GetA() const
{
	return a;
}

int VecType::GetB() const
{
	return b;
}

int VecType::GetC() const
{
	return c;
}